package cli.parkinglot.service;

public interface AbstractService
{

}